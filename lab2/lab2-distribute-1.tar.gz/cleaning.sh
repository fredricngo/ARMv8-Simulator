#!/bin/bash
rm test/*.txt dumpsim src/dumpsim
