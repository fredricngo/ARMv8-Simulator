#!/bin/bash
rm test/*.txt dumpsim lab1-tests.txt src/dumpsim