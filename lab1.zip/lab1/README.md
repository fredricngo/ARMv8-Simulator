![alt text](https://global.uchicago.edu/sites/default/files/styles/thumbnail_in_listing_s/public/2022-08/GUNAWI_Haryadi_500x700.jpg?itok=5p6ocpVK)
